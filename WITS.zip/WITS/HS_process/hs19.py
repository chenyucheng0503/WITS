import HS_loop

HS_loop.get_hs(19)